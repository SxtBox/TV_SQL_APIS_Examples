<?php
define('BASEPATH','');
// LINKED DIRECT TO CI DATABASE
function db_connection() {
include_once("../application/config/database.php");
$host_name = $db['default']['hostname'];
$db_user = $db['default']['username'];
$db_password = $db['default']['password'];
$db_name = $db['default']['database'];

$conn = mysqli_connect($host_name,$db_user,$db_password, $db_name)
   or die("Cannot connect to mySQL");
return $conn;
}