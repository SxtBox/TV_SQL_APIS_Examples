<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'streaming';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['api'] = 'api/get_data';
