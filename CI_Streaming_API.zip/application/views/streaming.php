<!DOCTYPE html>
<html>
    <head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Streaming Data</title>
	<link rel="shortcut icon" href="<?php echo base_url(); ?>favicon.ico"/>
    <link rel="icon" href="<?php echo base_url(); ?>favicon.ico"/>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/datatables/css/dataTables.bootstrap.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
    </head> 
<body>
    <div class="container">
	<!----/>
    <h1 style="font-size:10pt">Streaming Data Ajax CRUD Wth Bootstrap Modals and Datatables</h1>
	<!---->
        <h3>Streaming Data</h3>
        <br />
        <button class="btn btn-success btn-sm" onclick="add_stream()">
		<i class="glyphicon glyphicon-plus"></i> Add New Stream</button>

        <button class="btn btn-success btn-sm" onclick="reload_table()">
		<i class="glyphicon glyphicon-refresh"></i> Reload</button>

        <a class="btn btn-success btn-sm" href="<?php echo base_url() ?>api" target="_blank">JSON API</a>
        <a class="btn btn-success btn-sm" href="<?php echo base_url() ?>Extra_APIS" target="_blank">Extra APIS</a>
        <br />
        <br />
        <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Stream URL</th>
					<!---->
                    <th>Thumbnail</th>
					<!---->
					<!---->
                    <th>Fanart</th>
					<!---->
					<!---->
                    <th>Description</th>
					<!---->
					<th>Category</th>
                    <th style="width:125px;">Action</th>
                </tr>
            </thead>
            <tbody>
            </tbody>

            <tfoot>
            <tr>
                <th>Title</th>
                <th>Stream URL</th>
				<!---->
                <th>Thumbnail</th>
				<!---->
				<!---->
                <th>Fanart</th>
				<!---->
				<!---->
                <th>Description</th>
				<!---->
				<th>Category</th>
                <th>Action</th>
            </tr>
            </tfoot>
        </table>
    </div>

<script src="<?php echo base_url(); ?>assets/jquery/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/datatables/js/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

<script type="text/javascript">

var save_method; //for save method string
var table;

$(document).ready(function() {

    //datatables
    table = $('#table').DataTable({ 

        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.

        // Load data for the table's content from an Ajax source
        "ajax": {
        "url": "<?php echo site_url('streaming/streaming_list')?>",
        "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": [ -1 ], //last column
            "orderable": false, //set not orderable
        },
        ],

    });

    //datepicker
	/*
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top auto",
        todayBtn: true,
        todayHighlight: true,  
    });
*/
});

function add_stream()
{
    save_method = 'add';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#modal_form').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add New Stream'); // Set Title to Bootstrap modal title
}

function edit_stream(stream_id)
{
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string

    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('streaming/streaming_edit/')?>/" + stream_id,
        type: "GET",
        dataType: "JSON",
        success: function(data)

        {
            $('[name="stream_id"]').val(data.stream_id);
            $('[name="title"]').val(data.title);
            $('[name="link"]').val(data.link);
            $('[name="thumbnail"]').val(data.thumbnail);
            $('[name="fanart"]').val(data.fanart);
			$('[name="description"]').val(data.description);
			$('[name="category"]').val(data.category);
            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Stream'); // Set title to Bootstrap modal title
        },

        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error Get Data From Ajax');
        }
    });
}

function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}

function save()
{
    $('#btnSave').text('Saving Data...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;

    if(save_method == 'add') {
        url = "<?php echo site_url('streaming/streaming_add')?>";
    } else {
        url = "<?php echo site_url('streaming/streaming_update')?>";
    }

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form').serialize(),
        dataType: "JSON",
        success: function(data)
        {

            if(data.status) //if success close modal and reload ajax table
            {
                $('#modal_form').modal('hide');
                reload_table();
            }

            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
        },

        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error Adding or Update Data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 

        }
    });
}

function delete_stream(id)
{
    if(confirm('Are You Sure Delete This Data?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo site_url('streaming/streaming_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error Deleting Data');
            }
        });

    }
}
</script>

<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
                <h3 class="modal-title">Stream Form</h3>
            </div>

            <div class="modal-body form">
                <form action="#" id="form" class="form-horizontal">
                    <input type="hidden" value="" name="stream_id"/> 
                    <div class="form-body">

                        <div class="form-group">
                            <label class="control-label col-md-3">Stream Title</label>
                            <div class="col-md-9">
                                <input name="title" placeholder="Stream Title" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Stream URL</label>
                            <div class="col-md-9">
                                <input name="link" placeholder="Stream URL" class="form-control" type="text" required>
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Thumbnail</label>
                            <div class="col-md-9">
                                <input name="thumbnail" placeholder="Stream Thumbnail" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Fanart</label>
                            <div class="col-md-9">
                                <input name="fanart" placeholder="Stream Fanart" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Description</label>
                            <div class="col-md-9">
                                <input name="description" placeholder="Stream Description" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3">Category</label>
                            <div class="col-md-9">
                                <input name="category" placeholder="Stream Category" class="form-control" type="text">
                                <span class="help-block"></span>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
				 <button type="button" id="btnSave" onclick="save()" class="btn btn-success">Save</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->
</body>
</html>