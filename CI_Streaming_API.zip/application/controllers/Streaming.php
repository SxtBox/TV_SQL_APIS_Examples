<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Streaming extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('streaming_model','streaming');
	}

	public function index()
	{
		$this->load->helper('url');
		$this->load->view('streaming');
	}

	public function streaming_list()
	{
		$list = $this->streaming->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $item) {
			$no++;
			$row = array();
			$row[] = $item->title;
			$row[] = $item->link;
			$row[] = $item->thumbnail;
			$row[] = $item->fanart;
			$row[] = $item->description;
			$row[] = $item->category;

// title','link','thumbnail','fanart','description','category'

	//add html for action
	$row[] = '<a class="btn btn-sm btn-success" href="javascript:void(0)" title="Edit" onclick="edit_stream('."'".$item->stream_id."'".')"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
	
	<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Delete" onclick="delete_stream('."'".$item->stream_id."'".')"><i class="glyphicon glyphicon-trash"></i> Delete</a>';

	$data[] = $row;
	}

		$output = array(
			"draw"            => $_POST['draw'],
			"recordsTotal"    => $this->streaming->count_all(),
			"recordsFiltered" => $this->streaming->count_filtered(),
			"data" => $data,
		);
		//output json format
		echo json_encode($output);
	}

	public function streaming_edit($id)
	{
		$data = $this->streaming->get_by_id($id);
		echo json_encode($data);
	}

	public function streaming_add()
	{
		$data = array(
				'title'       => $this->input->post('title'),
				'link'        => $this->input->post('link'),
				'thumbnail'   => $this->input->post('thumbnail'),
				'fanart'      => $this->input->post('fanart'),
				'description' => $this->input->post('description'),
				'category'    => $this->input->post('category'),
			);

		$insert = $this->streaming->save($data);
		echo json_encode(array("status" => TRUE));
	}

	public function streaming_update()
	{
		$data = array(
				'title'       => $this->input->post('title'),
				'link'        => $this->input->post('link'),
				'thumbnail'   => $this->input->post('thumbnail'),
				'fanart'      => $this->input->post('fanart'),
				'description' => $this->input->post('description'),
				'category'    => $this->input->post('category'),
			);

		$this->streaming->update(array('stream_id' => $this->input->post('stream_id')), $data);
		echo json_encode(array("status" => TRUE));
	}


	public function streaming_delete($id)
	{
		$this->streaming->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

}
