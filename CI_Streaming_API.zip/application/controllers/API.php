<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class API extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Streaming_model');
	}

// JSON API
	function get_data()
	{
		$json_data = $this->Streaming_model->get_data();
		//echo json_encode($json_data);
		echo str_replace('\\/', '/',  json_encode($json_data));
	}

}
